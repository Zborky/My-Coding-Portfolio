import PyPDF2
import tkinter as tk
from tkinter import filedialog, scrolledtext

# Funkcia na otvorenie a načítanie PDF súboru
def open_pdf():
    # Otvorenie dialógového okna pre výber súboru
    file_path = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf")])
    
    if file_path:
        with open(file_path, "rb") as file:
            # Vytvorenie PDF čítačky
            reader = PyPDF2.PdfReader(file)
            
            # Prečítanie textu zo všetkých strán
            text = ""
            for page in range(len(reader.pages)):
                text += reader.pages[page].extract_text()
            
            # Zobrazenie textu v okne
            text_display.delete(1.0, tk.END)
            highlight_uppercase_words(text)

# Funkcia na zvýraznenie veľkých písmen červenou farbou
def highlight_uppercase_words(text):
    lines = text.splitlines()  # Rozdelenie textu na riadky
    for line in lines:
        words = line.split()  # Rozdelenie riadku na slová
        for word in words:
            if word.isupper():  # Ak je slovo celé veľkým písmom
                text_display.insert(tk.END, word + " ", "red")
            else:
                text_display.insert(tk.END, word + " ")
        text_display.insert(tk.END, "\n")  # Pridanie konca riadku

    # Definovanie štýlu pre červené zvýraznenie
    text_display.tag_config("red", foreground="red")

# Vytvorenie hlavného okna aplikácie
root = tk.Tk()
root.title("PDF Reader")

# Nastavenie väčšej veľkosti okna
root.geometry("1000x700")  # Šírka 1000 pixelov, výška 700 pixelov

# Tlačidlo na otvorenie PDF súboru
open_button = tk.Button(root, text="Open PDF", command=open_pdf)
open_button.pack(pady=10)

# Väčšie textové pole pre zobrazenie PDF textu s možnosťou scrollovania
text_display = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=120, height=35)
text_display.pack(padx=10, pady=10)

# Spustenie hlavnej slučky
root.mainloop()
